"""Este módulo ejecuta el modelo SSD MobileNet V1 mediante TensorFlow Lite."""
import cv2
import numpy as np

import configuracion as cfg

try:                                   # El módulo busca un intérprete compatible, en orden de preferencia
    from tflite_runtime.interpreter import Interpreter
except ImportError:
    try:
        from ai_edge_litert.interpreter import Interpreter
    except ImportError:
        from tensorflow.lite.python.interpreter import Interpreter


class Detector:
    def __init__(self, ruta_modelo=cfg.RUTA_MODELO, ruta_etiquetas=cfg.RUTA_ETIQUETAS,
                 umbral=cfg.UMBRAL_CONFIANZA):
        self.umbral = umbral
        self.interprete = Interpreter(model_path=ruta_modelo)
        self.interprete.allocate_tensors()
        entrada = self.interprete.get_input_details()[0]
        self.indice_entrada = entrada["index"]
        self.alto, self.ancho = entrada["shape"][1], entrada["shape"][2]
        self.flotante = entrada["dtype"] == np.float32
        self.salidas = self.interprete.get_output_details()

        with open(ruta_etiquetas, encoding="utf-8") as f:
            self.etiquetas = [linea.strip() for linea in f]
        if self.etiquetas and self.etiquetas[0] == "???":
            del self.etiquetas[0]

    def detectar(self, frame):
        """El método recibe un cuadro BGR y devuelve una lista de detecciones con
        la forma {'clase', 'confianza', 'caja': (x1, y1, x2, y2)} en píxeles."""
        alto_f, ancho_f = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)          # OpenCV convierte la imagen de BGR a RGB
        rgb = cv2.resize(rgb, (self.ancho, self.alto))        # OpenCV la ajusta al tamaño de entrada del modelo
        entrada = np.expand_dims(rgb, axis=0)
        if self.flotante:                                      # El detector normaliza la imagen al rango [-1, 1] si el modelo es flotante
            entrada = (np.float32(entrada) - 127.5) / 127.5

        self.interprete.set_tensor(self.indice_entrada, entrada)
        self.interprete.invoke()

        # El modelo entrega cuatro salidas: cajas, clases, puntuaciones y cantidad
        cajas = self.interprete.get_tensor(self.salidas[0]["index"])[0]
        clases = self.interprete.get_tensor(self.salidas[1]["index"])[0]
        puntajes = self.interprete.get_tensor(self.salidas[2]["index"])[0]

        detecciones = []
        for caja, clase, puntaje in zip(cajas, clases, puntajes):
            if puntaje < self.umbral:
                continue
            ymin, xmin, ymax, xmax = caja                      # El modelo entrega las coordenadas normalizadas entre 0 y 1
            x1, x2 = int(max(0, xmin) * ancho_f), int(min(1, xmax) * ancho_f)
            y1, y2 = int(max(0, ymin) * alto_f), int(min(1, ymax) * alto_f)
            idx = int(clase)
            nombre = self.etiquetas[idx] if idx < len(self.etiquetas) else f"clase {idx}"
            detecciones.append({"clase": nombre, "confianza": float(puntaje),
                                "caja": (x1, y1, x2, y2)})
        return detecciones
