"""Este módulo es el servidor Flask de la interfaz web y reutiliza detector.py y tracker.py."""
import os
import sys
import threading
import time
from collections import deque
from datetime import datetime

import cv2
from flask import Flask, Response, jsonify, render_template

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import configuracion as cfg                      # noqa: E402
from detector import Detector                    # noqa: E402
from tracker import Tracker                      # noqa: E402
from main import dibujar                         # noqa: E402

app = Flask(__name__)


class ServicioCamara:
    def __init__(self):
        self.detector = None
        self.tracker = Tracker()
        self.activo = False
        self.hilo = None
        self.frame_jpg = None
        self.fps = 0.0
        self.visibles = 0
        self.objetos_actuales = []
        self.historial = deque(maxlen=50)
        self.bloqueo = threading.Lock()

    def iniciar(self):
        if self.activo:
            return
        if self.detector is None:
            self.detector = Detector()
        self.tracker = Tracker()
        self.historial.clear()
        self.activo = True
        self.hilo = threading.Thread(target=self._bucle, daemon=True)
        self.hilo.start()

    def detener(self):
        self.activo = False
        if self.hilo:
            self.hilo.join(timeout=3)

    def _bucle(self):
        cam = cv2.VideoCapture(cfg.INDICE_CAMARA)
        cam.set(cv2.CAP_PROP_FRAME_WIDTH, cfg.ANCHO_IMAGEN)
        cam.set(cv2.CAP_PROP_FRAME_HEIGHT, cfg.ALTO_IMAGEN)
        previo = time.time()
        while self.activo:
            ok, frame = cam.read()
            if not ok:
                break
            objetos = self.tracker.actualizar(self.detector.detectar(frame))
            dibujar(frame, objetos)
            for id_ in self.tracker.nuevos:
                o = next(x for x in objetos if x["id"] == id_)
                self.historial.appendleft({"hora": datetime.now().strftime("%H:%M:%S"),
                                           "id": id_, "clase": o["clase"],
                                           "confianza": round(o["confianza"] * 100)})
            ahora = time.time()
            with self.bloqueo:
                self.fps = 1 / max(ahora - previo, 1e-6)
                self.visibles = len(objetos)
                self.objetos_actuales = [
                    {"id": o["id"], "clase": o["clase"], "confianza": round(o["confianza"] * 100)}
                    for o in objetos]
                self.frame_jpg = cv2.imencode(".jpg", frame)[1].tobytes()
            previo = ahora
        cam.release()
        self.activo = False
        with self.bloqueo:
            self.frame_jpg = None
            self.objetos_actuales = []


servicio = ServicioCamara()


@app.route("/")
def index():
    return render_template("index.html")


def generar_video():
    while True:
        with servicio.bloqueo:
            jpg = servicio.frame_jpg
        if jpg:
            yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
        time.sleep(0.03)


@app.route("/video")
def video():
    return Response(generar_video(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/api/iniciar", methods=["POST"])
def iniciar():
    try:
        servicio.iniciar()
        return jsonify(ok=True)
    except Exception as e:                       # El servidor captura aquí errores como un modelo faltante o una cámara ocupada
        return jsonify(ok=False, error=str(e)), 500


@app.route("/api/detener", methods=["POST"])
def detener():
    servicio.detener()
    return jsonify(ok=True)


@app.route("/api/estado")
def estado():
    return jsonify(activo=servicio.activo, fps=round(servicio.fps, 1),
                   visibles=servicio.visibles, conteo=servicio.tracker.conteo,
                   total=sum(servicio.tracker.conteo.values()),
                   objetos=servicio.objetos_actuales,
                   config=dict(umbral=cfg.UMBRAL_CONFIANZA, distancia=cfg.DISTANCIA_MAXIMA,
                               margen=cfg.MAX_FPS_DESAPARECIDO,
                               resolucion=f"{cfg.ANCHO_IMAGEN}x{cfg.ALTO_IMAGEN}"),
                   historial=list(servicio.historial))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, threaded=True)
