"""Este módulo almacena los parámetros generales del Object Tracker."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

INDICE_CAMARA = 0                  # El índice de la cámara; el valor 0 corresponde a la predeterminada
UMBRAL_CONFIANZA = 0.5             # El detector descarta toda detección con confianza menor a este valor
DISTANCIA_MAXIMA = 80              # El tracker conserva un ID solo si la distancia (px) no supera este valor
MAX_FPS_DESAPARECIDO = 30          # El tracker mantiene el registro de un objeto oculto durante estos cuadros
ANCHO_IMAGEN = 640                 # La cámara captura imágenes con esta resolución
ALTO_IMAGEN = 480
RUTA_MODELO = os.path.join(BASE_DIR, "modelo", "detect.tflite")
RUTA_ETIQUETAS = os.path.join(BASE_DIR, "modelo", "labelmap.txt")
