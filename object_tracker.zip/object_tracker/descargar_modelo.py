"""Descarga SSD MobileNet V1 (TFLite, cuantizado) en la carpeta modelo/."""
import io
import os
import urllib.request
import zipfile

import configuracion as cfg

URL = ("https://storage.googleapis.com/download.tensorflow.org/models/tflite/"
       "coco_ssd_mobilenet_v1_1.0_quant_2018_06_29.zip")

if __name__ == "__main__":
    os.makedirs(os.path.dirname(cfg.RUTA_MODELO), exist_ok=True)
    print("Descargando modelo...")
    datos = urllib.request.urlopen(URL).read()
    with zipfile.ZipFile(io.BytesIO(datos)) as z:
        for origen, destino in (("detect.tflite", cfg.RUTA_MODELO),
                                ("labelmap.txt", cfg.RUTA_ETIQUETAS)):
            with open(destino, "wb") as f:
                f.write(z.read(origen))
    print("Listo:", os.path.dirname(cfg.RUTA_MODELO))
