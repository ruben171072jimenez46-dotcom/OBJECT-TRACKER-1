"""Este script descarga SSD MobileNet V1 (TFLite, cuantizado) y lo guarda en la carpeta modelo/."""
# El script importa io para manejar el archivo descargado en memoria.
import io
# El script importa os para crear carpetas.
import os
# El script importa urllib.request para descargar el archivo desde internet.
import urllib.request
# El script importa zipfile para abrir el archivo comprimido.
import zipfile

# El script importa la configuración para conocer las rutas de destino.
import configuracion as cfg

# La constante URL guarda la dirección donde se encuentra el modelo comprimido.
URL = ("https://storage.googleapis.com/download.tensorflow.org/models/tflite/"
       "coco_ssd_mobilenet_v1_1.0_quant_2018_06_29.zip")

# El bloque siguiente se ejecuta solo cuando el usuario corre este archivo directamente.
if __name__ == "__main__":
    # El script crea la carpeta modelo/ si todavía no existe.
    os.makedirs(os.path.dirname(cfg.RUTA_MODELO), exist_ok=True)
    # El script avisa al usuario que inicia la descarga.
    print("Descargando modelo...")
    # El script descarga todo el contenido del zip y lo guarda en memoria.
    datos = urllib.request.urlopen(URL).read()
    # El script abre el zip descargado.
    with zipfile.ZipFile(io.BytesIO(datos)) as z:
        # El script recorre los dos archivos que necesita: el modelo y las etiquetas.
        for origen, destino in (("detect.tflite", cfg.RUTA_MODELO),
                                ("labelmap.txt", cfg.RUTA_ETIQUETAS)):
            # El script abre el archivo de destino en modo binario para escribirlo.
            with open(destino, "wb") as f:
                # El script extrae el archivo del zip y lo guarda en la carpeta modelo/.
                f.write(z.read(origen))
    # El script avisa al usuario que la descarga terminó y muestra la carpeta.
    print("Listo:", os.path.dirname(cfg.RUTA_MODELO))
