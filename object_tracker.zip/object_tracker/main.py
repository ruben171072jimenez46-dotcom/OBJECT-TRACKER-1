"""Módulo principal: aplicación de consola (ESC para salir)."""
import time

import cv2

import configuracion as cfg
from detector import Detector
from tracker import Tracker


def dibujar(frame, objetos):
    for o in objetos:
        x1, y1, x2, y2 = o["caja"]
        color = (37 * o["id"] % 255, 90 + 53 * o["id"] % 165, 200 - 29 * o["id"] % 180)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        texto = f'ID {o["id"]} {o["clase"]} {o["confianza"]:.0%}'
        cv2.putText(frame, texto, (x1, max(15, y1 - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
        cx, cy = map(int, o["centroide"])
        cv2.circle(frame, (cx, cy), 4, color, -1)


def main():
    detector = Detector()
    tracker = Tracker()

    cam = cv2.VideoCapture(cfg.INDICE_CAMARA)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, cfg.ANCHO_IMAGEN)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, cfg.ALTO_IMAGEN)
    if not cam.isOpened():
        raise RuntimeError("No se pudo abrir la cámara.")

    previo = time.time()
    while True:
        ok, frame = cam.read()
        if not ok:
            break
        objetos = tracker.actualizar(detector.detectar(frame))
        dibujar(frame, objetos)

        ahora = time.time()
        fps = 1 / max(ahora - previo, 1e-6)
        previo = ahora
        cv2.putText(frame, f"FPS: {fps:.1f}  Objetos: {len(objetos)}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.imshow("Object Tracker", frame)

        if cv2.waitKey(1) & 0xFF == 27:          # ESC
            break

    cam.release()
    cv2.destroyAllWindows()
    print("Conteo total por clase:", tracker.conteo)


if __name__ == "__main__":
    main()
