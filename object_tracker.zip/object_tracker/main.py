"""Este módulo principal controla la aplicación de consola; el usuario la cierra con la tecla ESC."""
# El módulo importa time para medir el tiempo entre cuadros.
import time

# El módulo importa OpenCV para manejar la cámara y dibujar.
import cv2

# El módulo importa la configuración del proyecto.
import configuracion as cfg
# El módulo importa el detector de objetos.
from detector import Detector
# El módulo importa el algoritmo de seguimiento.
from tracker import Tracker


# Esta función dibuja los rectángulos, el ID y la clase sobre el cuadro.
def dibujar(frame, objetos):
    # La función recorre cada objeto visible.
    for o in objetos:
        # La función separa las coordenadas de la caja del objeto.
        x1, y1, x2, y2 = o["caja"]
        # La función calcula un color distinto para cada identificador.
        color = (37 * o["id"] % 255, 90 + 53 * o["id"] % 165, 200 - 29 * o["id"] % 180)
        # La función dibuja el rectángulo alrededor del objeto.
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        # La función arma el texto con el ID, la clase y la confianza.
        texto = f'ID {o["id"]} {o["clase"]} {o["confianza"]:.0%}'
        # La función escribe el texto encima del rectángulo.
        cv2.putText(frame, texto, (x1, max(15, y1 - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
        # La función convierte el centroide a números enteros.
        cx, cy = map(int, o["centroide"])
        # La función dibuja un punto en el centro del objeto.
        cv2.circle(frame, (cx, cy), 4, color, -1)


# Esta función ejecuta el ciclo principal de la aplicación de consola.
def main():
    # La función crea el detector, que carga el modelo de IA.
    detector = Detector()
    # La función crea el tracker, que asigna los identificadores.
    tracker = Tracker()

    # La función abre la cámara con el índice configurado.
    cam = cv2.VideoCapture(cfg.INDICE_CAMARA)
    # La función establece el ancho de captura.
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, cfg.ANCHO_IMAGEN)
    # La función establece el alto de captura.
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, cfg.ALTO_IMAGEN)
    # La función detiene el programa con un error si la cámara no se abrió.
    if not cam.isOpened():
        raise RuntimeError("No se pudo abrir la cámara.")

    # La función guarda el instante inicial para calcular los FPS.
    previo = time.time()
    # La función repite el ciclo de procesamiento hasta que el usuario lo detiene.
    while True:
        # La función obtiene un cuadro de la cámara.
        ok, frame = cam.read()
        # La función termina el ciclo si no pudo leer el cuadro.
        if not ok:
            break
        # La función detecta los objetos y actualiza el seguimiento en un solo paso.
        objetos = tracker.actualizar(detector.detectar(frame))
        # La función dibuja los resultados sobre el cuadro.
        dibujar(frame, objetos)

        # La función toma el instante actual.
        ahora = time.time()
        # La función calcula los FPS a partir del tiempo transcurrido entre cuadros.
        fps = 1 / max(ahora - previo, 1e-6)
        # La función guarda el instante actual para el siguiente cuadro.
        previo = ahora
        # La función escribe los FPS y el número de objetos en la esquina de la imagen.
        cv2.putText(frame, f"FPS: {fps:.1f}  Objetos: {len(objetos)}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        # La función muestra el cuadro procesado en una ventana.
        cv2.imshow("Object Tracker", frame)

        # El ciclo termina cuando el usuario presiona la tecla ESC.
        if cv2.waitKey(1) & 0xFF == 27:
            break

    # La función libera la cámara.
    cam.release()
    # La función cierra las ventanas de OpenCV.
    cv2.destroyAllWindows()
    # La función imprime el conteo total de objetos por clase.
    print("Conteo total por clase:", tracker.conteo)


# El bloque siguiente se ejecuta solo cuando el usuario corre este archivo directamente.
if __name__ == "__main__":
    main()
