"""Este módulo ejecuta el modelo SSD MobileNet V1 mediante TensorFlow Lite."""
# El módulo importa OpenCV para procesar imágenes.
import cv2
# El módulo importa NumPy para manejar arreglos numéricos.
import numpy as np

# El módulo importa la configuración con el umbral y las rutas.
import configuracion as cfg

# El módulo busca un intérprete compatible, en orden de preferencia.
try:
    # El módulo intenta primero con tflite_runtime.
    from tflite_runtime.interpreter import Interpreter
# Si tflite_runtime no existe, el módulo prueba con otra opción.
except ImportError:
    try:
        # El módulo intenta con ai_edge_litert.
        from ai_edge_litert.interpreter import Interpreter
    # Si tampoco existe, el módulo usa el intérprete de TensorFlow.
    except ImportError:
        from tensorflow.lite.python.interpreter import Interpreter


# La clase Detector encapsula la carga del modelo y la detección de objetos.
class Detector:
    # El constructor recibe las rutas del modelo y de las etiquetas, y el umbral de confianza.
    def __init__(self, ruta_modelo=cfg.RUTA_MODELO, ruta_etiquetas=cfg.RUTA_ETIQUETAS,
                 umbral=cfg.UMBRAL_CONFIANZA):
        # El detector guarda el umbral de confianza.
        self.umbral = umbral
        # El detector carga el modelo desde el archivo .tflite.
        self.interprete = Interpreter(model_path=ruta_modelo)
        # El detector reserva la memoria que necesita el modelo.
        self.interprete.allocate_tensors()
        # El detector consulta los datos de la entrada del modelo.
        entrada = self.interprete.get_input_details()[0]
        # El detector guarda el índice de la entrada para enviarle imágenes después.
        self.indice_entrada = entrada["index"]
        # El detector guarda el alto y el ancho que el modelo espera recibir.
        self.alto, self.ancho = entrada["shape"][1], entrada["shape"][2]
        # El detector comprueba si el modelo trabaja con números decimales o con enteros.
        self.flotante = entrada["dtype"] == np.float32
        # El detector guarda los datos de las salidas del modelo.
        self.salidas = self.interprete.get_output_details()

        # El detector abre el archivo de etiquetas.
        with open(ruta_etiquetas, encoding="utf-8") as f:
            # El detector lee cada línea del archivo y le quita los espacios sobrantes.
            self.etiquetas = [linea.strip() for linea in f]
        # El detector revisa si la primera etiqueta es un marcador vacío.
        if self.etiquetas and self.etiquetas[0] == "???":
            # El detector elimina ese marcador para que los índices coincidan con las clases.
            del self.etiquetas[0]

    def detectar(self, frame):
        """El método recibe un cuadro BGR y devuelve una lista de detecciones con
        la forma {'clase', 'confianza', 'caja': (x1, y1, x2, y2)} en píxeles."""
        # El método obtiene el alto y el ancho originales del cuadro.
        alto_f, ancho_f = frame.shape[:2]
        # OpenCV convierte la imagen de BGR a RGB.
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # OpenCV la ajusta al tamaño de entrada del modelo.
        rgb = cv2.resize(rgb, (self.ancho, self.alto))
        # El método agrega una dimensión extra porque el modelo espera un lote de imágenes.
        entrada = np.expand_dims(rgb, axis=0)
        # El detector normaliza la imagen al rango [-1, 1] si el modelo es flotante.
        if self.flotante:
            entrada = (np.float32(entrada) - 127.5) / 127.5

        # El método entrega la imagen al modelo.
        self.interprete.set_tensor(self.indice_entrada, entrada)
        # El método ejecuta el modelo.
        self.interprete.invoke()

        # El modelo entrega cuatro salidas: cajas, clases, puntuaciones y cantidad.
        # El método lee las cajas de los objetos detectados.
        cajas = self.interprete.get_tensor(self.salidas[0]["index"])[0]
        # El método lee el número de clase de cada objeto.
        clases = self.interprete.get_tensor(self.salidas[1]["index"])[0]
        # El método lee la confianza de cada detección.
        puntajes = self.interprete.get_tensor(self.salidas[2]["index"])[0]

        # El método prepara la lista donde guardará los resultados.
        detecciones = []
        # El método recorre cada detección junto con su clase y su confianza.
        for caja, clase, puntaje in zip(cajas, clases, puntajes):
            # El método descarta las detecciones con confianza menor al umbral.
            if puntaje < self.umbral:
                continue
            # El modelo entrega las coordenadas normalizadas entre 0 y 1.
            ymin, xmin, ymax, xmax = caja
            # El método convierte las coordenadas horizontales a píxeles y las limita al cuadro.
            x1, x2 = int(max(0, xmin) * ancho_f), int(min(1, xmax) * ancho_f)
            # El método convierte las coordenadas verticales a píxeles y las limita al cuadro.
            y1, y2 = int(max(0, ymin) * alto_f), int(min(1, ymax) * alto_f)
            # El método convierte el número de clase en un entero.
            idx = int(clase)
            # El método busca el nombre de la clase; si no existe, usa un nombre genérico.
            nombre = self.etiquetas[idx] if idx < len(self.etiquetas) else f"clase {idx}"
            # El método agrega la detección a la lista de resultados.
            detecciones.append({"clase": nombre, "confianza": float(puntaje),
                                "caja": (x1, y1, x2, y2)})
        # El método devuelve todas las detecciones encontradas.
        return detecciones
