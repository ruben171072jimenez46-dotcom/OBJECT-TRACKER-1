// La aplicación importa la librería matemática de Dart con el nombre math.
import 'dart:math' as math;
// La aplicación importa los tipos de datos para manejar bytes.
import 'dart:typed_data';

// La aplicación importa el paquete que controla la cámara.
import 'package:camera/camera.dart';
// La aplicación importa los componentes visuales de Flutter.
import 'package:flutter/material.dart';
// La aplicación importa los servicios del sistema, como la lectura de archivos del proyecto.
import 'package:flutter/services.dart';
// La aplicación importa el paquete que ejecuta el modelo TensorFlow Lite.
import 'package:tflite_flutter/tflite_flutter.dart';

// La aplicación define aquí sus parámetros de configuración.
// El detector descarta las detecciones con confianza menor a este valor.
const double umbralConfianza = 0.5;
// La distancia se expresa como fracción de la imagen (coordenadas normalizadas).
const double distanciaMaxima = 0.15;
// El tracker conserva un objeto oculto durante este número de cuadros.
const int maxCuadrosDesaparecido = 30;
// El modelo espera imágenes cuadradas de este tamaño en píxeles.
const int tamEntrada = 300;

// La aplicación define aquí las clases que representan los datos.
// Esta clase representa una detección que entrega el modelo.
class Deteccion {
  // La detección guarda el nombre de la clase.
  final String clase;
  // La detección guarda la confianza del modelo.
  final double confianza;
  // La caja usa coordenadas normalizadas entre 0 y 1.
  final Rect caja;
  // El constructor recibe los tres datos en orden.
  Deteccion(this.clase, this.confianza, this.caja);
}

// Esta clase representa un objeto al que el tracker da seguimiento.
class Objeto {
  // El objeto guarda su identificador, que no cambia.
  final int id;
  // El objeto guarda su clase, que no cambia.
  final String clase;
  // El objeto guarda la posición de su centro.
  Offset centroide;
  // El objeto guarda su caja actual.
  Rect caja;
  // El objeto guarda su confianza más reciente.
  double confianza;
  // El objeto cuenta los cuadros consecutivos en que no se vio.
  int desaparecido = 0;
  // El constructor recibe los datos iniciales del objeto.
  Objeto(this.id, this.clase, this.centroide, this.caja, this.confianza);
}

// El tracker da seguimiento a los objetos mediante centroides.
class Tracker {
  // El tracker inicia el contador de identificadores en 1.
  int _siguienteId = 1;
  // Este mapa guarda los objetos registrados, indexados por su identificador.
  final Map<int, Objeto> objetos = {};
  // Este mapa cuenta los objetos distintos vistos por clase.
  final Map<String, int> conteo = {};

  // Este método calcula el centro de un rectángulo.
  Offset _centroide(Rect c) => Offset((c.left + c.right) / 2, (c.top + c.bottom) / 2);

  // Este método asocia las detecciones con los objetos conocidos y devuelve los visibles.
  List<Objeto> actualizar(List<Deteccion> dets) {
    // El método calcula el centroide de cada detección.
    final centros = dets.map((d) => _centroide(d.caja)).toList();
    // Cada par contiene la distancia, el id y el índice de la detección.
    final pares = <List<num>>[];
    // El método recorre cada objeto ya registrado.
    objetos.forEach((id, o) {
      // El método compara el objeto con cada detección.
      for (var i = 0; i < dets.length; i++) {
        // El método ignora las detecciones de otra clase.
        if (o.clase != dets[i].clase) continue;
        // La aplicación calcula la distancia euclidiana entre los centroides.
        final d = (centros[i] - o.centroide).distance;
        // El método conserva el par si la distancia no supera el máximo.
        if (d <= distanciaMaxima) pares.add([d, id, i]);
      }
    });
    // El método ordena los pares de menor a mayor distancia.
    pares.sort((a, b) => a[0].compareTo(b[0]));

    // El método prepara los conjuntos de objetos y detecciones ya emparejados.
    final usados = <int>{};
    final detsUsadas = <int>{};
    // El método prepara el mapa que relaciona cada detección con un identificador.
    final asignacion = <int, int>{};
    // El método recorre los pares del más cercano al más lejano.
    for (final p in pares) {
      // El método obtiene el identificador y el índice del par.
      final id = p[1].toInt(), i = p[2].toInt();
      // El método salta el par si el objeto o la detección ya tienen pareja.
      if (usados.contains(id) || detsUsadas.contains(i)) continue;
      // El método marca el objeto como emparejado.
      usados.add(id);
      // El método marca la detección como emparejada.
      detsUsadas.add(i);
      // El método anota el identificador que corresponde a la detección.
      asignacion[i] = id;
    }

    // El método revisa cada objeto registrado.
    for (final id in objetos.keys.toList()) {
      // El método actúa sobre los objetos que no recibieron pareja.
      if (!usados.contains(id)) {
        // El método suma un cuadro de ausencia.
        objetos[id]!.desaparecido++;
        // El método elimina el objeto si superó el margen permitido.
        if (objetos[id]!.desaparecido > maxCuadrosDesaparecido) objetos.remove(id);
      }
    }
    // El método recorre las detecciones para registrar las que no tienen pareja.
    for (var i = 0; i < dets.length; i++) {
      // El método salta las detecciones que ya tienen pareja.
      if (detsUsadas.contains(i)) continue;
      // El método toma un identificador nuevo y avanza el contador.
      final id = _siguienteId++;
      // El método registra el objeto nuevo.
      objetos[id] = Objeto(id, dets[i].clase, centros[i], dets[i].caja, dets[i].confianza);
      // El método suma uno al conteo de la clase.
      conteo[dets[i].clase] = (conteo[dets[i].clase] ?? 0) + 1;
      // El método anota el identificador asignado a la detección.
      asignacion[i] = id;
    }

    // El método prepara la lista de objetos visibles.
    final visibles = <Objeto>[];
    // El método recorre cada detección con su identificador asignado.
    for (var i = 0; i < dets.length; i++) {
      // El método obtiene el objeto correspondiente.
      final o = objetos[asignacion[i]]!;
      // El método actualiza su centroide.
      o.centroide = centros[i];
      // El método actualiza su caja.
      o.caja = dets[i].caja;
      // El método actualiza su confianza.
      o.confianza = dets[i].confianza;
      // El método reinicia su contador de ausencia.
      o.desaparecido = 0;
      // El método agrega el objeto a la lista de visibles.
      visibles.add(o);
    }
    // El método devuelve los objetos visibles.
    return visibles;
  }
}

// El detector ejecuta el modelo con TensorFlow Lite.
class Detector {
  // El detector guarda el intérprete del modelo, que se carga más tarde.
  late final Interpreter _interprete;
  // El detector guarda la lista de nombres de las clases.
  late final List<String> etiquetas;

  // Este método carga el modelo y las etiquetas desde los recursos de la aplicación.
  Future<void> cargar() async {
    // El método carga el modelo desde el archivo .tflite.
    _interprete = await Interpreter.fromAsset('assets/detect.tflite');
    // El método lee el archivo de etiquetas como texto.
    final texto = await rootBundle.loadString('assets/labelmap.txt');
    // El método separa el texto por líneas, quita espacios y descarta las líneas vacías.
    etiquetas = texto.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    // El método elimina el marcador vacío del inicio para que los índices coincidan.
    if (etiquetas.isNotEmpty && etiquetas.first == '???') etiquetas.removeAt(0);
  }

  /// Este método convierte el cuadro YUV420 de la cámara a RGB de 300x300 y lo rota a vertical.
  Uint8List _preprocesar(CameraImage img) {
    // El método obtiene el ancho y el alto del cuadro original.
    final w = img.width, h = img.height;
    // El método obtiene los tres planos de color del formato YUV.
    final yP = img.planes[0], uP = img.planes[1], vP = img.planes[2];
    // El método calcula las dimensiones de la imagen en vertical.
    final pw = h, ph = w;
    // El método prepara el arreglo de salida con tres bytes por píxel.
    final out = Uint8List(tamEntrada * tamEntrada * 3);
    // El método inicia el índice de escritura en cero.
    var k = 0;
    // El método recorre cada fila de la imagen de salida.
    for (var oy = 0; oy < tamEntrada; oy++) {
      // El método recorre cada columna de la imagen de salida.
      for (var ox = 0; ox < tamEntrada; ox++) {
        // El método calcula la columna correspondiente en la imagen vertical.
        final px = (ox * pw / tamEntrada).floor();
        // El método calcula la fila correspondiente en la imagen vertical.
        final py = (oy * ph / tamEntrada).floor();
        // El método rota la imagen 90° en sentido horario.
        final sx = py, sy = h - 1 - px;
        // El método lee la luminosidad del píxel.
        final y = yP.bytes[sy * yP.bytesPerRow + sx];
        // El método calcula la posición del color en los planos U y V.
        final uvIdx = (sy ~/ 2) * uP.bytesPerRow + (sx ~/ 2) * (uP.bytesPerPixel ?? 1);
        // El método lee los componentes de color U y V centrados en cero.
        final u = uP.bytes[uvIdx] - 128, v = vP.bytes[uvIdx] - 128;
        // El método calcula y guarda el componente rojo.
        out[k++] = (y + 1.402 * v).round().clamp(0, 255);
        // El método calcula y guarda el componente verde.
        out[k++] = (y - 0.344 * u - 0.714 * v).round().clamp(0, 255);
        // El método calcula y guarda el componente azul.
        out[k++] = (y + 1.772 * u).round().clamp(0, 255);
      }
    }
    // El método devuelve la imagen lista para el modelo.
    return out;
  }

  // Este método detecta los objetos que aparecen en un cuadro de la cámara.
  List<Deteccion> detectar(CameraImage img) {
    // El método prepara la imagen y le da la forma que el modelo espera.
    final entrada = _preprocesar(img).reshape([1, tamEntrada, tamEntrada, 3]);
    // El método prepara el espacio para las cajas de hasta 10 objetos.
    final cajas = List.generate(1, (_) => List.generate(10, (_) => List.filled(4, 0.0)));
    // El método prepara el espacio para las clases.
    final clases = List.generate(1, (_) => List.filled(10, 0.0));
    // El método prepara el espacio para las confianzas.
    final puntajes = List.generate(1, (_) => List.filled(10, 0.0));
    // El método prepara el espacio para la cantidad de detecciones.
    final cantidad = List.filled(1, 0.0);
    // El método ejecuta el modelo y recibe las cuatro salidas.
    _interprete.runForMultipleInputs([entrada], {0: cajas, 1: clases, 2: puntajes, 3: cantidad});

    // El método prepara la lista de resultados.
    final res = <Deteccion>[];
    // El método revisa cada una de las 10 posibles detecciones.
    for (var i = 0; i < 10; i++) {
      // El método obtiene la confianza de la detección.
      final p = puntajes[0][i];
      // El método descarta las detecciones con confianza menor al umbral.
      if (p < umbralConfianza) continue;
      // El modelo entrega cada caja como ymin, xmin, ymax, xmax.
      final c = cajas[0][i];
      // El método convierte el número de clase en un entero.
      final idx = clases[0][i].toInt();
      // El método busca el nombre de la clase; si no existe, usa uno genérico.
      final nombre = idx < etiquetas.length ? etiquetas[idx] : 'clase $idx';
      // El método agrega la detección con la caja limitada al rango de 0 a 1.
      res.add(Deteccion(nombre, p, Rect.fromLTRB(c[1].clamp(0.0, 1.0), c[0].clamp(0.0, 1.0),
          c[3].clamp(0.0, 1.0), c[2].clamp(0.0, 1.0))));
    }
    // El método devuelve las detecciones encontradas.
    return res;
  }
}

// La aplicación define aquí la interfaz y sus pantallas.
// Esta variable global guarda las cámaras disponibles del dispositivo.
late List<CameraDescription> camaras;

// Esta función es el punto de entrada de la aplicación.
Future<void> main() async {
  // La función prepara Flutter antes de usar la cámara.
  WidgetsFlutterBinding.ensureInitialized();
  // La función consulta las cámaras disponibles.
  camaras = await availableCameras();
  // La función inicia la aplicación.
  runApp(const ObjectTrackerApp());
}

// Esta clase define la aplicación y sus temas visuales.
class ObjectTrackerApp extends StatelessWidget {
  // El constructor no recibe datos.
  const ObjectTrackerApp({super.key});
  // Este método construye la aplicación.
  @override
  Widget build(BuildContext context) => MaterialApp(
        // La aplicación muestra este título en el sistema.
        title: 'Object Tracker',
        // La aplicación oculta la etiqueta de modo de depuración.
        debugShowCheckedModeBanner: false,
        // La aplicación define el tema claro con un color base azul.
        theme: ThemeData(colorSchemeSeed: const Color(0xFF2F6FED), useMaterial3: true),
        // La aplicación define el tema oscuro con el mismo color base.
        darkTheme: ThemeData(
            colorSchemeSeed: const Color(0xFF2F6FED),
            brightness: Brightness.dark,
            useMaterial3: true),
        // La aplicación abre la pantalla principal.
        home: const Principal(),
      );
}

// Esta clase representa la pantalla principal, que cambia con el tiempo.
class Principal extends StatefulWidget {
  // El constructor no recibe datos.
  const Principal({super.key});
  // Este método crea el estado asociado a la pantalla.
  @override
  State<Principal> createState() => _PrincipalState();
}

// Esta clase guarda el estado y la lógica de la pantalla principal.
class _PrincipalState extends State<Principal> {
  // Esta variable indica cuál de las cuatro pantallas se muestra.
  int pantalla = 0;
  // La aplicación crea el detector.
  final detector = Detector();
  // La aplicación crea el tracker.
  final tracker = Tracker();
  // Esta variable guarda el controlador de la cámara.
  CameraController? camara;
  // Estas variables indican si el modelo está listo, si la detección está activa y si hay un cuadro en proceso.
  bool listo = false, activo = false, procesando = false;
  // Esta lista guarda los objetos visibles en este momento.
  List<Objeto> visibles = [];
  // Esta variable guarda los FPS calculados.
  double fps = 0;
  // Esta variable guarda el instante del cuadro anterior.
  DateTime previo = DateTime.now();
  // Esta lista guarda el historial de detecciones.
  final List<String> historial = [];

  // Este método se ejecuta cuando la pantalla se crea.
  @override
  void initState() {
    // El método ejecuta primero la inicialización de Flutter.
    super.initState();
    // El método carga el modelo y marca la aplicación como lista al terminar.
    detector.cargar().then((_) => setState(() => listo = true));
  }

  // Este método se ejecuta cuando la pantalla se destruye.
  @override
  void dispose() {
    // El método libera la cámara.
    camara?.dispose();
    // El método ejecuta la limpieza de Flutter.
    super.dispose();
  }

  // Este método inicia la cámara y el procesamiento de cuadros.
  Future<void> iniciar() async {
    // El método crea el controlador con la primera cámara, resolución media y sin audio.
    camara = CameraController(camaras.first, ResolutionPreset.medium,
        enableAudio: false, imageFormatGroup: ImageFormatGroup.yuv420);
    // El método inicializa la cámara.
    await camara!.initialize();
    // El método comienza a enviar cada cuadro a la función de procesamiento.
    await camara!.startImageStream(_procesar);
    // El método marca la detección como activa.
    setState(() => activo = true);
  }

  // Este método detiene la cámara.
  Future<void> detener() async {
    // El método detiene el envío de cuadros.
    await camara?.stopImageStream();
    // El método libera la cámara.
    await camara?.dispose();
    // El método borra la referencia a la cámara.
    camara = null;
    // El método actualiza la pantalla.
    setState(() {
      // El método marca la detección como inactiva.
      activo = false;
      // El método vacía la lista de objetos visibles.
      visibles = [];
    });
  }

  // Este método procesa cada cuadro que entrega la cámara.
  void _procesar(CameraImage img) {
    // La aplicación descarta cuadros cuando el modelo aún procesa el anterior.
    if (procesando) return;
    // El método marca que empezó a procesar un cuadro.
    procesando = true;
    // El método detecta los objetos del cuadro.
    final dets = detector.detectar(img);
    // El método calcula cuántos objetos se habían contado antes de actualizar.
    final antes = tracker.conteo.values.fold(0, (a, b) => a + b);
    // El método actualiza el seguimiento con las nuevas detecciones.
    final res = tracker.actualizar(dets);
    // El método calcula cuántos objetos se han contado después de actualizar.
    final despues = tracker.conteo.values.fold(0, (a, b) => a + b);
    // El método revisa si apareció un objeto nuevo.
    if (despues > antes) {
      // El método elige el objeto con el identificador más alto, que es el más reciente.
      final o = res.reduce((a, b) => a.id > b.id ? a : b);
      // El método obtiene la hora actual en formato legible.
      final t = TimeOfDay.now().format(context);
      // El método agrega el registro al inicio del historial.
      historial.insert(0, '$t  ·  ID ${o.id}  ·  ${o.clase}');
      // El método conserva solo los últimos 50 registros.
      if (historial.length > 50) historial.removeLast();
    }
    // El método toma el instante actual.
    final ahora = DateTime.now();
    // El método calcula los FPS a partir del tiempo transcurrido.
    fps = 1000 / math.max(1, ahora.difference(previo).inMilliseconds);
    // El método guarda el instante actual para el siguiente cuadro.
    previo = ahora;
    // El método actualiza la pantalla con los objetos visibles, si la pantalla sigue abierta.
    if (mounted) setState(() => visibles = res);
    // El método marca que terminó de procesar el cuadro.
    procesando = false;
  }

  // Este método construye la interfaz de la pantalla principal.
  @override
  Widget build(BuildContext context) {
    // El método prepara la lista de las cuatro pantallas.
    final paginas = [
      // La primera pantalla es el inicio.
      _inicio(),
      // La segunda pantalla es la detección.
      _deteccion(),
      // La tercera pantalla son las estadísticas.
      _estadisticas(),
      // La cuarta pantalla es la información del proyecto.
      _informacion(),
    ];
    // El método devuelve la estructura básica de la pantalla.
    return Scaffold(
      // La aplicación muestra una barra superior con el título.
      appBar: AppBar(title: const Text('Object Tracker')),
      // La aplicación muestra la pantalla elegida dentro del área segura.
      body: SafeArea(child: paginas[pantalla]),
      // La aplicación muestra la barra de navegación inferior.
      bottomNavigationBar: NavigationBar(
        // La barra resalta la pantalla actual.
        selectedIndex: pantalla,
        // La barra cambia de pantalla cuando el usuario toca una opción.
        onDestinationSelected: (i) => setState(() => pantalla = i),
        // La barra tiene cuatro opciones.
        destinations: const [
          // Esta opción lleva al inicio.
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Inicio'),
          // Esta opción lleva a la detección.
          NavigationDestination(icon: Icon(Icons.videocam_outlined), label: 'Detección'),
          // Esta opción lleva a las estadísticas.
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Estadísticas'),
          // Esta opción lleva a la información.
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'Info'),
        ],
      ),
    );
  }

  // Esta pantalla muestra el inicio.
  Widget _inicio() => Center(
        // El contenido tiene espacio interior.
        child: Padding(
          padding: const EdgeInsets.all(24),
          // El contenido se acomoda en una columna del tamaño mínimo necesario.
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // La pantalla muestra un icono grande.
            const Icon(Icons.center_focus_strong, size: 80),
            // La pantalla deja un espacio vertical.
            const SizedBox(height: 16),
            // La pantalla muestra el nombre de la aplicación.
            Text('Object Tracker', style: Theme.of(context).textTheme.headlineMedium),
            // La pantalla deja un espacio vertical.
            const SizedBox(height: 8),
            // La pantalla muestra la descripción del sistema.
            const Text('Detección y seguimiento de objetos en tiempo real',
                textAlign: TextAlign.center),
            // La pantalla deja un espacio vertical.
            const SizedBox(height: 24),
            // La pantalla muestra el botón para comenzar.
            FilledButton.icon(
              // El botón lleva a la pantalla de detección, y se desactiva mientras el modelo carga.
              onPressed: listo ? () => setState(() => pantalla = 1) : null,
              // El botón muestra un icono de reproducción.
              icon: const Icon(Icons.play_arrow),
              // El botón indica si el modelo todavía se está cargando.
              label: Text(listo ? 'Comenzar' : 'Cargando modelo...'),
            ),
          ]),
        ),
      );

  // Esta pantalla muestra la cámara con la detección.
  Widget _deteccion() => Column(children: [
        // La cámara ocupa todo el espacio disponible.
        Expanded(
          // La pantalla muestra la cámara solo si está activa y lista.
          child: activo && camara != null && camara!.value.isInitialized
              // La pantalla mide el espacio disponible.
              ? LayoutBuilder(builder: (context, c) {
                  // La pantalla apila la vista de la cámara y los rectángulos.
                  return Stack(fit: StackFit.expand, children: [
                    // La pantalla muestra la imagen de la cámara.
                    CameraPreview(camara!),
                    // La pantalla dibuja los rectángulos encima de la imagen.
                    CustomPaint(painter: Cajas(visibles)),
                  ]);
                })
              // La pantalla muestra este texto cuando la cámara está detenida.
              : const Center(child: Text('Cámara detenida')),
        ),
        // La pantalla agrega una fila inferior con datos y botón.
        Padding(
          padding: const EdgeInsets.all(12),
          // La fila reparte sus elementos a los extremos.
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            // La fila muestra los FPS y el número de objetos.
            Text('FPS ${fps.toStringAsFixed(1)} · Objetos ${visibles.length}'),
            // La fila muestra Detener si está activo, o Iniciar si no lo está.
            activo
                ? OutlinedButton(onPressed: detener, child: const Text('Detener'))
                : FilledButton(onPressed: listo ? iniciar : null, child: const Text('Iniciar')),
          ]),
        ),
      ]);

  // Esta pantalla muestra las estadísticas y el historial.
  Widget _estadisticas() => ListView(padding: const EdgeInsets.all(16), children: [
        // La pantalla muestra el total de objetos contados.
        Card(
          child: ListTile(
            title: const Text('Objetos contados'),
            // El total se calcula sumando el conteo de todas las clases.
            trailing: Text('${tracker.conteo.values.fold(0, (a, b) => a + b)}',
                style: Theme.of(context).textTheme.headlineSmall),
          ),
        ),
        // La pantalla muestra los FPS.
        Card(child: ListTile(title: const Text('FPS'), trailing: Text(fps.toStringAsFixed(1)))),
        // La pantalla muestra el título del contador por clase.
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 8),
            child: Text('Contador por clase', style: TextStyle(fontWeight: FontWeight.w600))),
        // La pantalla muestra una fila por cada clase contada.
        ...tracker.conteo.entries
            .map((e) => ListTile(title: Text(e.key), trailing: Text('${e.value}'))),
        // La pantalla muestra el título del historial.
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 8),
            child: Text('Historial', style: TextStyle(fontWeight: FontWeight.w600))),
        // La pantalla muestra una fila por cada registro del historial.
        ...historial.map((h) => ListTile(dense: true, title: Text(h))),
      ]);

  // Esta pantalla muestra la información del proyecto.
  Widget _informacion() => ListView(padding: const EdgeInsets.all(16), children: const [
        // La pantalla muestra el título de la sección.
        Text('Información del proyecto',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        // La pantalla deja un espacio vertical.
        SizedBox(height: 12),
        // La pantalla muestra la descripción del proyecto.
        Text('Versión 1.0\n\n'
            'Modelo: SSD MobileNet V1 (TensorFlow Lite) ejecutado directamente en el dispositivo.\n\n'
            'Seguimiento: algoritmo de centroides con distancia euclidiana; cada objeto nuevo '
            'recibe un identificador que se conserva mientras permanezca cerca y sea de la misma clase.\n\n'
            'Limitaciones: la calidad depende de la iluminación y de la cámara; los objetos ocultos '
            'demasiado tiempo pierden su identificador.\n\n'
            'Tecnológico de Tláhuac II · Redes Neuronales Artificiales'),
      ]);
}

// Esta clase dibuja los rectángulos, el ID y la clase sobre la vista previa.
class Cajas extends CustomPainter {
  // La clase guarda la lista de objetos que debe dibujar.
  final List<Objeto> objetos;
  // El constructor recibe esa lista.
  Cajas(this.objetos);

  // Este método dibuja los objetos sobre el lienzo.
  @override
  void paint(Canvas canvas, Size size) {
    // El método recorre cada objeto visible.
    for (final o in objetos) {
      // El método elige un color según el identificador del objeto.
      final color = Colors.primaries[o.id % Colors.primaries.length];
      // El método convierte la caja normalizada a píxeles del lienzo.
      final r = Rect.fromLTRB(o.caja.left * size.width, o.caja.top * size.height,
          o.caja.right * size.width, o.caja.bottom * size.height);
      // El método dibuja el contorno del rectángulo.
      canvas.drawRect(
          r,
          Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3);
      // El método prepara el texto con el ID, la clase y la confianza.
      final tp = TextPainter(
        text: TextSpan(
            text: ' ID ${o.id} ${o.clase} ${(o.confianza * 100).round()}% ',
            style: TextStyle(color: Colors.white, backgroundColor: color, fontSize: 13)),
        textDirection: TextDirection.ltr,
      )..layout();
      // El método dibuja el texto encima del rectángulo.
      tp.paint(canvas, Offset(r.left, math.max(0, r.top - tp.height)));
    }
  }

  // El método indica que debe redibujar en cada cuadro.
  @override
  bool shouldRepaint(covariant Cajas old) => true;
}
