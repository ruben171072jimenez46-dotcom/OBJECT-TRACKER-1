import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

// ───────────── Configuración ─────────────
const double umbralConfianza = 0.5;
const double distanciaMaxima = 0.15; // fracción de la imagen (coordenadas normalizadas)
const int maxCuadrosDesaparecido = 30;
const int tamEntrada = 300;

// ───────────── Modelos de datos ─────────────
class Deteccion {
  final String clase;
  final double confianza;
  final Rect caja; // normalizada 0..1
  Deteccion(this.clase, this.confianza, this.caja);
}

class Objeto {
  final int id;
  final String clase;
  Offset centroide;
  Rect caja;
  double confianza;
  int desaparecido = 0;
  Objeto(this.id, this.clase, this.centroide, this.caja, this.confianza);
}

// ───────────── Seguimiento por centroides ─────────────
class Tracker {
  int _siguienteId = 1;
  final Map<int, Objeto> objetos = {};
  final Map<String, int> conteo = {};

  Offset _centroide(Rect c) => Offset((c.left + c.right) / 2, (c.top + c.bottom) / 2);

  List<Objeto> actualizar(List<Deteccion> dets) {
    final centros = dets.map((d) => _centroide(d.caja)).toList();
    final pares = <List<num>>[]; // [distancia, id, índice]
    objetos.forEach((id, o) {
      for (var i = 0; i < dets.length; i++) {
        if (o.clase != dets[i].clase) continue;
        final d = (centros[i] - o.centroide).distance; // distancia euclidiana
        if (d <= distanciaMaxima) pares.add([d, id, i]);
      }
    });
    pares.sort((a, b) => a[0].compareTo(b[0]));

    final usados = <int>{};
    final detsUsadas = <int>{};
    final asignacion = <int, int>{};
    for (final p in pares) {
      final id = p[1].toInt(), i = p[2].toInt();
      if (usados.contains(id) || detsUsadas.contains(i)) continue;
      usados.add(id);
      detsUsadas.add(i);
      asignacion[i] = id;
    }

    for (final id in objetos.keys.toList()) {
      if (!usados.contains(id)) {
        objetos[id]!.desaparecido++;
        if (objetos[id]!.desaparecido > maxCuadrosDesaparecido) objetos.remove(id);
      }
    }
    for (var i = 0; i < dets.length; i++) {
      if (detsUsadas.contains(i)) continue;
      final id = _siguienteId++;
      objetos[id] = Objeto(id, dets[i].clase, centros[i], dets[i].caja, dets[i].confianza);
      conteo[dets[i].clase] = (conteo[dets[i].clase] ?? 0) + 1;
      asignacion[i] = id;
    }

    final visibles = <Objeto>[];
    for (var i = 0; i < dets.length; i++) {
      final o = objetos[asignacion[i]]!;
      o.centroide = centros[i];
      o.caja = dets[i].caja;
      o.confianza = dets[i].confianza;
      o.desaparecido = 0;
      visibles.add(o);
    }
    return visibles;
  }
}

// ───────────── Detector TensorFlow Lite ─────────────
class Detector {
  late final Interpreter _interprete;
  late final List<String> etiquetas;

  Future<void> cargar() async {
    _interprete = await Interpreter.fromAsset('assets/detect.tflite');
    final texto = await rootBundle.loadString('assets/labelmap.txt');
    etiquetas = texto.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    if (etiquetas.isNotEmpty && etiquetas.first == '???') etiquetas.removeAt(0);
  }

  /// Convierte el cuadro YUV420 de la cámara a RGB 300x300 (rotado a vertical).
  Uint8List _preprocesar(CameraImage img) {
    final w = img.width, h = img.height;
    final yP = img.planes[0], uP = img.planes[1], vP = img.planes[2];
    final pw = h, ph = w; // dimensiones en vertical
    final out = Uint8List(tamEntrada * tamEntrada * 3);
    var k = 0;
    for (var oy = 0; oy < tamEntrada; oy++) {
      for (var ox = 0; ox < tamEntrada; ox++) {
        final px = (ox * pw / tamEntrada).floor();
        final py = (oy * ph / tamEntrada).floor();
        final sx = py, sy = h - 1 - px; // rotación 90° horario
        final y = yP.bytes[sy * yP.bytesPerRow + sx];
        final uvIdx = (sy ~/ 2) * uP.bytesPerRow + (sx ~/ 2) * (uP.bytesPerPixel ?? 1);
        final u = uP.bytes[uvIdx] - 128, v = vP.bytes[uvIdx] - 128;
        out[k++] = (y + 1.402 * v).round().clamp(0, 255);
        out[k++] = (y - 0.344 * u - 0.714 * v).round().clamp(0, 255);
        out[k++] = (y + 1.772 * u).round().clamp(0, 255);
      }
    }
    return out;
  }

  List<Deteccion> detectar(CameraImage img) {
    final entrada = _preprocesar(img).reshape([1, tamEntrada, tamEntrada, 3]);
    final cajas = List.generate(1, (_) => List.generate(10, (_) => List.filled(4, 0.0)));
    final clases = List.generate(1, (_) => List.filled(10, 0.0));
    final puntajes = List.generate(1, (_) => List.filled(10, 0.0));
    final cantidad = List.filled(1, 0.0);
    _interprete.runForMultipleInputs([entrada], {0: cajas, 1: clases, 2: puntajes, 3: cantidad});

    final res = <Deteccion>[];
    for (var i = 0; i < 10; i++) {
      final p = puntajes[0][i];
      if (p < umbralConfianza) continue;
      final c = cajas[0][i]; // ymin, xmin, ymax, xmax
      final idx = clases[0][i].toInt();
      final nombre = idx < etiquetas.length ? etiquetas[idx] : 'clase $idx';
      res.add(Deteccion(nombre, p, Rect.fromLTRB(c[1].clamp(0.0, 1.0), c[0].clamp(0.0, 1.0),
          c[3].clamp(0.0, 1.0), c[2].clamp(0.0, 1.0))));
    }
    return res;
  }
}

// ───────────── Aplicación ─────────────
late List<CameraDescription> camaras;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  camaras = await availableCameras();
  runApp(const ObjectTrackerApp());
}

class ObjectTrackerApp extends StatelessWidget {
  const ObjectTrackerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Object Tracker',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF2F6FED), useMaterial3: true),
        darkTheme: ThemeData(
            colorSchemeSeed: const Color(0xFF2F6FED),
            brightness: Brightness.dark,
            useMaterial3: true),
        home: const Principal(),
      );
}

class Principal extends StatefulWidget {
  const Principal({super.key});
  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  int pantalla = 0;
  final detector = Detector();
  final tracker = Tracker();
  CameraController? camara;
  bool listo = false, activo = false, procesando = false;
  List<Objeto> visibles = [];
  double fps = 0;
  DateTime previo = DateTime.now();
  final List<String> historial = [];

  @override
  void initState() {
    super.initState();
    detector.cargar().then((_) => setState(() => listo = true));
  }

  @override
  void dispose() {
    camara?.dispose();
    super.dispose();
  }

  Future<void> iniciar() async {
    camara = CameraController(camaras.first, ResolutionPreset.medium,
        enableAudio: false, imageFormatGroup: ImageFormatGroup.yuv420);
    await camara!.initialize();
    await camara!.startImageStream(_procesar);
    setState(() => activo = true);
  }

  Future<void> detener() async {
    await camara?.stopImageStream();
    await camara?.dispose();
    camara = null;
    setState(() {
      activo = false;
      visibles = [];
    });
  }

  void _procesar(CameraImage img) {
    if (procesando) return; // descarta cuadros si el modelo no alcanza
    procesando = true;
    final dets = detector.detectar(img);
    final antes = tracker.conteo.values.fold(0, (a, b) => a + b);
    final res = tracker.actualizar(dets);
    final despues = tracker.conteo.values.fold(0, (a, b) => a + b);
    if (despues > antes) {
      final o = res.reduce((a, b) => a.id > b.id ? a : b);
      final t = TimeOfDay.now().format(context);
      historial.insert(0, '$t  ·  ID ${o.id}  ·  ${o.clase}');
      if (historial.length > 50) historial.removeLast();
    }
    final ahora = DateTime.now();
    fps = 1000 / math.max(1, ahora.difference(previo).inMilliseconds);
    previo = ahora;
    if (mounted) setState(() => visibles = res);
    procesando = false;
  }

  @override
  Widget build(BuildContext context) {
    final paginas = [
      _inicio(),
      _deteccion(),
      _estadisticas(),
      _informacion(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Object Tracker')),
      body: SafeArea(child: paginas[pantalla]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: pantalla,
        onDestinationSelected: (i) => setState(() => pantalla = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Inicio'),
          NavigationDestination(icon: Icon(Icons.videocam_outlined), label: 'Detección'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Estadísticas'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'Info'),
        ],
      ),
    );
  }

  // Pantalla 1: Inicio
  Widget _inicio() => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.center_focus_strong, size: 80),
            const SizedBox(height: 16),
            Text('Object Tracker', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            const Text('Detección y seguimiento de objetos en tiempo real',
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: listo ? () => setState(() => pantalla = 1) : null,
              icon: const Icon(Icons.play_arrow),
              label: Text(listo ? 'Comenzar' : 'Cargando modelo...'),
            ),
          ]),
        ),
      );

  // Pantalla 2: Detección
  Widget _deteccion() => Column(children: [
        Expanded(
          child: activo && camara != null && camara!.value.isInitialized
              ? LayoutBuilder(builder: (context, c) {
                  return Stack(fit: StackFit.expand, children: [
                    CameraPreview(camara!),
                    CustomPaint(painter: Cajas(visibles)),
                  ]);
                })
              : const Center(child: Text('Cámara detenida')),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('FPS ${fps.toStringAsFixed(1)} · Objetos ${visibles.length}'),
            activo
                ? OutlinedButton(onPressed: detener, child: const Text('Detener'))
                : FilledButton(onPressed: listo ? iniciar : null, child: const Text('Iniciar')),
          ]),
        ),
      ]);

  // Pantalla 3: Estadísticas
  Widget _estadisticas() => ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          child: ListTile(
            title: const Text('Objetos contados'),
            trailing: Text('${tracker.conteo.values.fold(0, (a, b) => a + b)}',
                style: Theme.of(context).textTheme.headlineSmall),
          ),
        ),
        Card(child: ListTile(title: const Text('FPS'), trailing: Text(fps.toStringAsFixed(1)))),
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 8),
            child: Text('Contador por clase', style: TextStyle(fontWeight: FontWeight.w600))),
        ...tracker.conteo.entries
            .map((e) => ListTile(title: Text(e.key), trailing: Text('${e.value}'))),
        const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 8),
            child: Text('Historial', style: TextStyle(fontWeight: FontWeight.w600))),
        ...historial.map((h) => ListTile(dense: true, title: Text(h))),
      ]);

  // Pantalla 4: Información
  Widget _informacion() => ListView(padding: const EdgeInsets.all(16), children: const [
        Text('Información del proyecto',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        SizedBox(height: 12),
        Text('Versión 1.0\n\n'
            'Modelo: SSD MobileNet V1 (TensorFlow Lite) ejecutado directamente en el dispositivo.\n\n'
            'Seguimiento: algoritmo de centroides con distancia euclidiana; cada objeto nuevo '
            'recibe un identificador que se conserva mientras permanezca cerca y sea de la misma clase.\n\n'
            'Limitaciones: la calidad depende de la iluminación y de la cámara; los objetos ocultos '
            'demasiado tiempo pierden su identificador.\n\n'
            'Tecnológico de Tláhuac II · Redes Neuronales Artificiales'),
      ]);
}

// Dibuja rectángulos, ID y clase sobre la vista previa
class Cajas extends CustomPainter {
  final List<Objeto> objetos;
  Cajas(this.objetos);

  @override
  void paint(Canvas canvas, Size size) {
    for (final o in objetos) {
      final color = Colors.primaries[o.id % Colors.primaries.length];
      final r = Rect.fromLTRB(o.caja.left * size.width, o.caja.top * size.height,
          o.caja.right * size.width, o.caja.bottom * size.height);
      canvas.drawRect(
          r,
          Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3);
      final tp = TextPainter(
        text: TextSpan(
            text: ' ID ${o.id} ${o.clase} ${(o.confianza * 100).round()}% ',
            style: TextStyle(color: Colors.white, backgroundColor: color, fontSize: 13)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(r.left, math.max(0, r.top - tp.height)));
    }
  }

  @override
  bool shouldRepaint(covariant Cajas old) => true;
}
