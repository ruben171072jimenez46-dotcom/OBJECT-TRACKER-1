APP MÓVIL (Flutter) – pasos para compilar
1. flutter create .            (dentro de la carpeta movil/, conserva lib/ y pubspec.yaml)
2. Copiar modelo/detect.tflite y modelo/labelmap.txt a movil/assets/
3. android/app/src/main/AndroidManifest.xml: agregar
     <uses-permission android:name="android.permission.CAMERA"/>
4. android/app/build.gradle: minSdkVersion 26 (o superior)
5. flutter pub get && flutter run
