"""Módulo de configuración: parámetros generales del Object Tracker."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

INDICE_CAMARA = 0                  # Índice de la cámara (0 = predeterminada)
UMBRAL_CONFIANZA = 0.5             # Confianza mínima para aceptar una detección
DISTANCIA_MAXIMA = 80              # Distancia euclidiana máxima (px) para conservar un ID
MAX_FPS_DESAPARECIDO = 30          # Cuadros que se conserva un objeto sin verse
ANCHO_IMAGEN = 640                 # Resolución de captura
ALTO_IMAGEN = 480
RUTA_MODELO = os.path.join(BASE_DIR, "modelo", "detect.tflite")
RUTA_ETIQUETAS = os.path.join(BASE_DIR, "modelo", "labelmap.txt")
