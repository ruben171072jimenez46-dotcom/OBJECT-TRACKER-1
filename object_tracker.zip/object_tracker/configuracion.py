"""Este módulo almacena los parámetros generales del Object Tracker."""
# El programa importa el módulo os para trabajar con rutas de archivos.
import os

# El programa guarda la carpeta donde se encuentra este archivo como base de las demás rutas.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# El índice de la cámara; el valor 0 corresponde a la predeterminada.
INDICE_CAMARA = 0
# El detector descarta toda detección con confianza menor a este valor.
UMBRAL_CONFIANZA = 0.5
# El tracker conserva un ID solo si la distancia (px) no supera este valor.
DISTANCIA_MAXIMA = 80
# El tracker mantiene el registro de un objeto oculto durante estos cuadros.
MAX_FPS_DESAPARECIDO = 30
# La cámara captura imágenes con este ancho en píxeles.
ANCHO_IMAGEN = 640
# La cámara captura imágenes con este alto en píxeles.
ALTO_IMAGEN = 480
# El programa construye la ruta del modelo de IA a partir de la carpeta base.
RUTA_MODELO = os.path.join(BASE_DIR, "modelo", "detect.tflite")
# El programa construye la ruta del archivo de etiquetas a partir de la carpeta base.
RUTA_ETIQUETAS = os.path.join(BASE_DIR, "modelo", "labelmap.txt")
