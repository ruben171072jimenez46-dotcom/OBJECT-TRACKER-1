# Object Tracker v1.0

Detección y seguimiento de objetos en tiempo real (SSD MobileNet V1 + TFLite + OpenCV + centroides).

## Estructura
- `configuracion.py` · parámetros generales
- `detector.py` · detección con TensorFlow Lite
- `tracker.py` · seguimiento por centroides / distancia euclidiana
- `main.py` · aplicación de consola (ESC para salir)
- `web/` · interfaz web responsive con Flask
- `movil/` · app Android con Flutter (ver `movil/README_movil.txt`)

## Uso
```
pip install -r requirements.txt
python descargar_modelo.py      # descarga detect.tflite y labelmap.txt
python main.py                  # versión de consola
python web/app.py               # versión web -> http://localhost:5000
```
