"""Este módulo es el servidor Flask de la interfaz web y reutiliza detector.py y tracker.py."""
# El módulo importa os para trabajar con rutas.
import os
# El módulo importa sys para agregar carpetas a la ruta de búsqueda de módulos.
import sys
# El módulo importa threading para procesar la cámara en un hilo aparte.
import threading
# El módulo importa time para medir tiempos y esperar entre cuadros.
import time
# El módulo importa deque para guardar un historial de tamaño limitado.
from collections import deque
# El módulo importa datetime para registrar la hora de cada detección.
from datetime import datetime

# El módulo importa OpenCV para manejar la cámara y codificar imágenes.
import cv2
# El módulo importa las herramientas de Flask para crear rutas y respuestas.
from flask import Flask, Response, jsonify, render_template

# El módulo agrega la carpeta del proyecto a la ruta de búsqueda para poder importar los demás módulos.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# El módulo importa la configuración del proyecto.
import configuracion as cfg                      # noqa: E402
# El módulo importa el detector de objetos.
from detector import Detector                    # noqa: E402
# El módulo importa el algoritmo de seguimiento.
from tracker import Tracker                      # noqa: E402
# El módulo importa la función que dibuja los rectángulos sobre el cuadro.
from main import dibujar                         # noqa: E402

# El módulo crea la aplicación Flask.
app = Flask(__name__)


# Esta clase controla la cámara, el detector y el tracker mientras el sistema está activo.
class ServicioCamara:
    # El constructor prepara el estado inicial del servicio.
    def __init__(self):
        # El servicio crea el detector hasta que el usuario lo necesite.
        self.detector = None
        # El servicio crea un tracker vacío.
        self.tracker = Tracker()
        # El servicio indica que todavía no está en ejecución.
        self.activo = False
        # El servicio guarda aquí el hilo de procesamiento.
        self.hilo = None
        # El servicio guarda aquí el último cuadro codificado como JPEG.
        self.frame_jpg = None
        # El servicio guarda los FPS más recientes.
        self.fps = 0.0
        # El servicio guarda cuántos objetos se ven en pantalla.
        self.visibles = 0
        # El servicio guarda la lista de objetos visibles en este momento.
        self.objetos_actuales = []
        # El servicio guarda los últimos 50 registros del historial.
        self.historial = deque(maxlen=50)
        # El servicio crea un candado para que el hilo y las peticiones no choquen al leer los datos.
        self.bloqueo = threading.Lock()

    # Este método inicia la cámara y la detección.
    def iniciar(self):
        # El método no hace nada si el servicio ya está activo.
        if self.activo:
            return
        # El método carga el detector solo la primera vez.
        if self.detector is None:
            self.detector = Detector()
        # El método reinicia el tracker para empezar una cuenta nueva.
        self.tracker = Tracker()
        # El método vacía el historial anterior.
        self.historial.clear()
        # El método marca el servicio como activo.
        self.activo = True
        # El método crea el hilo que ejecutará el ciclo de la cámara.
        self.hilo = threading.Thread(target=self._bucle, daemon=True)
        # El método inicia el hilo.
        self.hilo.start()

    # Este método detiene la cámara.
    def detener(self):
        # El método marca el servicio como inactivo para que el ciclo termine.
        self.activo = False
        # El método espera hasta 3 segundos a que el hilo termine.
        if self.hilo:
            self.hilo.join(timeout=3)

    # Este método ejecuta el ciclo de captura, detección y seguimiento.
    def _bucle(self):
        # El método abre la cámara configurada.
        cam = cv2.VideoCapture(cfg.INDICE_CAMARA)
        # El método establece el ancho de captura.
        cam.set(cv2.CAP_PROP_FRAME_WIDTH, cfg.ANCHO_IMAGEN)
        # El método establece el alto de captura.
        cam.set(cv2.CAP_PROP_FRAME_HEIGHT, cfg.ALTO_IMAGEN)
        # El método guarda el instante inicial para calcular los FPS.
        previo = time.time()
        # El método repite el ciclo mientras el servicio esté activo.
        while self.activo:
            # El método obtiene un cuadro de la cámara.
            ok, frame = cam.read()
            # El método termina el ciclo si no pudo leer el cuadro.
            if not ok:
                break
            # El método detecta los objetos y actualiza el seguimiento.
            objetos = self.tracker.actualizar(self.detector.detectar(frame))
            # El método dibuja los resultados sobre el cuadro.
            dibujar(frame, objetos)
            # El método revisa los identificadores que el tracker registró como nuevos.
            for id_ in self.tracker.nuevos:
                # El método busca los datos del objeto nuevo.
                o = next(x for x in objetos if x["id"] == id_)
                # El método agrega un registro al inicio del historial.
                self.historial.appendleft({"hora": datetime.now().strftime("%H:%M:%S"),
                                           "id": id_, "clase": o["clase"],
                                           "confianza": round(o["confianza"] * 100)})
            # El método toma el instante actual.
            ahora = time.time()
            # El método bloquea el acceso mientras actualiza los datos compartidos.
            with self.bloqueo:
                # El método calcula los FPS.
                self.fps = 1 / max(ahora - previo, 1e-6)
                # El método guarda cuántos objetos hay en pantalla.
                self.visibles = len(objetos)
                # El método guarda la lista de objetos visibles con su ID, clase y confianza.
                self.objetos_actuales = [
                    {"id": o["id"], "clase": o["clase"], "confianza": round(o["confianza"] * 100)}
                    for o in objetos]
                # El método codifica el cuadro como JPEG para enviarlo al navegador.
                self.frame_jpg = cv2.imencode(".jpg", frame)[1].tobytes()
            # El método guarda el instante actual para el siguiente cuadro.
            previo = ahora
        # El método libera la cámara al terminar el ciclo.
        cam.release()
        # El método marca el servicio como inactivo.
        self.activo = False
        # El método bloquea el acceso mientras limpia los datos compartidos.
        with self.bloqueo:
            # El método borra el último cuadro.
            self.frame_jpg = None
            # El método vacía la lista de objetos visibles.
            self.objetos_actuales = []


# El módulo crea una única instancia del servicio para toda la aplicación.
servicio = ServicioCamara()


# Esta ruta entrega la página principal.
@app.route("/")
def index():
    # La función devuelve la plantilla index.html.
    return render_template("index.html")


# Esta función genera el flujo continuo de imágenes para el video.
def generar_video():
    # La función repite el envío indefinidamente.
    while True:
        # La función bloquea el acceso mientras lee el último cuadro.
        with servicio.bloqueo:
            # La función toma el último cuadro disponible.
            jpg = servicio.frame_jpg
        # La función envía el cuadro solo si existe.
        if jpg:
            # La función envía el cuadro con el formato que el navegador espera.
            yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
        # La función espera un instante antes de enviar el siguiente cuadro.
        time.sleep(0.03)


# Esta ruta entrega el video en vivo.
@app.route("/video")
def video():
    # La función devuelve el flujo de imágenes como una respuesta continua.
    return Response(generar_video(), mimetype="multipart/x-mixed-replace; boundary=frame")


# Esta ruta recibe la orden de iniciar el sistema.
@app.route("/api/iniciar", methods=["POST"])
def iniciar():
    # La función intenta iniciar el servicio.
    try:
        servicio.iniciar()
        # La función responde que todo salió bien.
        return jsonify(ok=True)
    # El servidor captura aquí errores como un modelo faltante o una cámara ocupada.
    except Exception as e:
        # La función responde con el mensaje del error y el código 500.
        return jsonify(ok=False, error=str(e)), 500


# Esta ruta recibe la orden de detener el sistema.
@app.route("/api/detener", methods=["POST"])
def detener():
    # La función detiene el servicio.
    servicio.detener()
    # La función responde que todo salió bien.
    return jsonify(ok=True)


# Esta ruta entrega el estado actual del sistema en formato JSON.
@app.route("/api/estado")
def estado():
    # La función devuelve todos los datos que la interfaz necesita mostrar.
    return jsonify(activo=servicio.activo, fps=round(servicio.fps, 1),
                   # La respuesta incluye los objetos en pantalla y el conteo por clase.
                   visibles=servicio.visibles, conteo=servicio.tracker.conteo,
                   # La respuesta incluye el total de objetos distintos contados.
                   total=sum(servicio.tracker.conteo.values()),
                   # La respuesta incluye la lista de objetos visibles.
                   objetos=servicio.objetos_actuales,
                   # La respuesta incluye los parámetros de la configuración.
                   config=dict(umbral=cfg.UMBRAL_CONFIANZA, distancia=cfg.DISTANCIA_MAXIMA,
                               margen=cfg.MAX_FPS_DESAPARECIDO,
                               resolucion=f"{cfg.ANCHO_IMAGEN}x{cfg.ALTO_IMAGEN}"),
                   # La respuesta incluye el historial de detecciones.
                   historial=list(servicio.historial))


# El bloque siguiente se ejecuta solo cuando el usuario corre este archivo directamente.
if __name__ == "__main__":
    # El programa inicia el servidor en el puerto 5000, accesible desde la red local.
    app.run(host="0.0.0.0", port=5000, threaded=True)
