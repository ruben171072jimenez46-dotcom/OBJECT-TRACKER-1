// Este script controla la interfaz del Object Tracker y se comunica con el servidor Flask.

// Esta función abrevia la búsqueda de elementos por su id.
const $ = (id) => document.getElementById(id);
// Este diccionario traduce al español los nombres de las clases más comunes.
const ES = {person:"Persona",car:"Automóvil",dog:"Perro",cat:"Gato",bicycle:"Bicicleta",motorcycle:"Motocicleta",
  bus:"Autobús",truck:"Camión",bottle:"Botella",chair:"Silla","cell phone":"Celular",laptop:"Laptop",cup:"Taza",book:"Libro"};
// Esta función devuelve el nombre en español de una clase, o el original si no tiene traducción.
const nombre = (c) => ES[c] || c;
// Esta función asigna un color distinto a cada identificador.
const color = (id) => `hsl(${(id * 67) % 360} 70% 48%)`;
// Estas variables guardan el temporizador de consulta, el modo actual y los datos de la demostración.
let timer = null, modo = null, demo = null;

// Esta función actualiza la etiqueta de estado de la cabecera.
function estado(txt, clase) {
  // La función aplica la clase de color que corresponde al estado.
  $("estado").className = "estado " + (clase || "");
  // La función escribe el texto del estado.
  $("estadoTxt").textContent = txt;
}

// Esta función dibuja en la página los datos que recibe del servidor.
function pintar(e) {
  // La función muestra los FPS.
  $("fps").textContent = e.fps;
  // La función muestra cuántos objetos hay en pantalla.
  $("visibles").textContent = e.visibles;
  // La función muestra el total de objetos distintos contados.
  $("total").textContent = e.total;
  // La función actualiza los parámetros de configuración solo si el servidor los envió.
  if (e.config) {
    // La función muestra la resolución.
    $("resolucion").textContent = e.config.resolucion;
    // La función muestra el umbral de confianza como porcentaje.
    $("umbral").textContent = Math.round(e.config.umbral * 100) + "%";
    // La función muestra la distancia máxima en píxeles.
    $("distancia").textContent = e.config.distancia + " px";
    // La función muestra el margen de FPS.
    $("margen").textContent = e.config.margen;
  }
  // La función ordena las clases de mayor a menor cantidad.
  const entradas = Object.entries(e.conteo).sort((a, b) => b[1] - a[1]);
  // La función calcula el valor máximo para dibujar las barras proporcionales.
  const max = Math.max(1, ...entradas.map((x) => x[1]));
  // La función arma el contador por clase, o un aviso si todavía no hay datos.
  $("conteo").innerHTML = entradas.length
    // La función crea una fila con el nombre, la cantidad y una barra por cada clase.
    ? entradas.map(([c, n]) => `<div class="fila"><div><span>${nombre(c)}</span><b>${n}</b></div><i style="width:${(n / max) * 100}%"></i></div>`).join("")
    // La función muestra este aviso cuando no hay clases contadas.
    : '<div class="vacioTxt">Sin datos todavía.</div>';
  // La función arma las etiquetas de los objetos en pantalla, o un aviso si no hay ninguno.
  $("objetos").innerHTML = e.objetos.length
    // La función crea una etiqueta con el ID, la clase y la confianza de cada objeto.
    ? e.objetos.map((o) => `<div class="chip"><b style="background:${color(o.id)}">ID ${o.id}</b>${nombre(o.clase)}<span>${o.confianza}%</span></div>`).join("")
    // La función muestra este aviso cuando no hay objetos detectados.
    : '<span class="vacioTxt">No hay objetos detectados.</span>';
  // La función arma las filas del historial, o un aviso si todavía está vacío.
  $("historial").innerHTML = e.historial.length
    // La función crea una fila con la hora, el ID, la clase y la confianza de cada registro.
    ? e.historial.map((h) => `<tr><td>${h.hora}</td><td>${h.id}</td><td>${nombre(h.clase)}</td><td>${h.confianza}%</td></tr>`).join("")
    // La función muestra este aviso cuando no hay detecciones.
    : '<tr><td colspan="4" class="vacioTxt">Aún no hay detecciones.</td></tr>';
}

// Esta función habilita o deshabilita los botones según el estado del sistema.
function ui(activo) {
  // La función desactiva el botón Iniciar cuando el sistema está activo.
  $("btnIniciar").disabled = activo;
  // La función desactiva el botón Detener cuando el sistema está inactivo.
  $("btnDetener").disabled = !activo;
  // La función oculta el letrero de cámara detenida cuando el sistema está activo.
  $("vacio").hidden = activo;
  // La función oculta el video y limpia su fuente cuando el sistema se detiene.
  if (!activo) { $("video").hidden = true; $("demo").hidden = true; $("video").removeAttribute("src"); }
}

// Esta función pide al servidor el estado actual del sistema.
async function consultar() {
  try {
    // La función solicita los datos al servidor y los convierte a objeto.
    const e = await (await fetch("/api/estado")).json();
    // La función muestra los datos en la página.
    pintar(e);
    // La función detiene la interfaz si el servidor ya no está activo.
    if (!e.activo && modo === "real") detener(false);
    // La función ignora los errores de conexión para volver a intentar en la siguiente consulta.
  } catch (_) {}
}

// Esta función solicita al servidor que inicie la cámara y la detección.
async function iniciar() {
  // La función avisa al usuario que está iniciando.
  $("msg").textContent = "Iniciando…";
  // La variable r guardará la respuesta del servidor.
  let r;
  try {
    // La función envía la orden de iniciar al servidor.
    r = await (await fetch("/api/iniciar", { method: "POST" })).json();
  } catch (_) {
    // La página entra en modo demostración si el servidor Flask no responde.
    return iniciarDemo();
  }
  // La función muestra el mensaje de error si el servidor respondió con un problema.
  if (!r.ok) { $("msg").textContent = "Error: " + r.error; return; }
  // La función registra que trabaja con el servidor real.
  modo = "real";
  // La función conecta el video en vivo del servidor.
  $("video").src = "/video?" + Date.now();
  // La función muestra el video.
  $("video").hidden = false;
  // La función actualiza los botones y la etiqueta de estado.
  ui(true); estado("En ejecución", "on"); $("msg").textContent = "";
  // La función consulta el estado del servidor cada 700 milisegundos.
  timer = setInterval(consultar, 700);
}

// Esta función solicita al servidor que detenga la cámara.
async function detener(avisar = true) {
  // La función cancela las consultas periódicas.
  clearInterval(timer); timer = null;
  // La función avisa al servidor que debe detenerse, si el modo es real.
  if (modo === "real" && avisar) { try { await fetch("/api/detener", { method: "POST" }); } catch (_) {} }
  // La función detiene la animación si el modo es demostración.
  if (modo === "demo") clearInterval(demo.reloj);
  // La función restablece el modo, los botones y la etiqueta de estado.
  modo = null; ui(false); estado("Detenido");
  // La función avisa al usuario que el sistema se detuvo.
  $("msg").textContent = "Detenido";
}

// El modo demostración simula datos únicamente cuando no se encuentra el servidor.
function iniciarDemo() {
  // La función registra que trabaja en modo demostración.
  modo = "demo";
  // La función obtiene el lienzo y su contexto de dibujo.
  const cv = $("demo"), g = cv.getContext("2d");
  // La función define las clases que puede simular.
  const clases = ["person", "dog", "car", "person", "bottle"];
  // La variable sig guarda el siguiente identificador disponible.
  let sig = 1;
  // La función prepara los datos de la simulación.
  demo = { objs: [], conteo: {}, hist: [], previo: performance.now(), fps: 0 };
  // Esta función crea un objeto simulado nuevo.
  const nuevo = () => {
    // La función elige una clase al azar.
    const c = clases[Math.floor(Math.random() * clases.length)];
    // La función define la posición, el tamaño, la velocidad, la confianza y la duración del objeto.
    const o = { id: sig++, clase: c, x: 40 + Math.random() * 380, y: 60 + Math.random() * 250,
      w: 110 + Math.random() * 80, h: 130 + Math.random() * 70, vx: (Math.random() - .5) * 3, vy: (Math.random() - .5) * 2,
      conf: 62 + Math.floor(Math.random() * 35), vida: 160 + Math.random() * 200 };
    // La función agrega el objeto a la lista.
    demo.objs.push(o);
    // La función suma uno al conteo de su clase.
    demo.conteo[c] = (demo.conteo[c] || 0) + 1;
    // La función agrega un registro al inicio del historial.
    demo.hist.unshift({ hora: new Date().toLocaleTimeString("es-MX", { hour12: false }), id: o.id, clase: c, confianza: o.conf });
    // La función conserva solo los últimos 50 registros.
    demo.hist = demo.hist.slice(0, 50);
  };
  // La función crea dos objetos iniciales.
  nuevo(); nuevo();
  // La función repite la animación cada 40 milisegundos.
  demo.reloj = setInterval(() => {
    // La función toma el instante actual.
    const ahora = performance.now();
    // La función calcula los FPS simulados y guarda el instante actual.
    demo.fps = Math.round((1000 / (ahora - demo.previo)) * 10) / 10; demo.previo = ahora;
    // La función crea un objeto nuevo de vez en cuando, con un máximo de cinco.
    if (Math.random() < .015 && demo.objs.length < 5) nuevo();
    // La función pinta el fondo del lienzo.
    g.fillStyle = "#0b1018"; g.fillRect(0, 0, 640, 480);
    // La función escribe el aviso de modo demostración.
    g.fillStyle = "#8793a8"; g.font = "13px system-ui"; g.fillText("MODO DEMOSTRACIÓN · datos simulados", 14, 22);
    // La función elimina los objetos cuya duración terminó.
    demo.objs = demo.objs.filter((o) => --o.vida > 0);
    // La función recorre cada objeto simulado.
    for (const o of demo.objs) {
      // La función mueve el objeto según su velocidad.
      o.x += o.vx; o.y += o.vy;
      // La función invierte el movimiento horizontal al llegar a un borde.
      if (o.x < 0 || o.x + o.w > 640) o.vx *= -1;
      // La función invierte el movimiento vertical al llegar a un borde.
      if (o.y < 30 || o.y + o.h > 480) o.vy *= -1;
      // La función dibuja el rectángulo del objeto.
      g.strokeStyle = color(o.id); g.lineWidth = 3; g.strokeRect(o.x, o.y, o.w, o.h);
      // La función arma el texto con el ID, la clase y la confianza.
      const t = `ID ${o.id} ${nombre(o.clase)} ${o.conf}%`;
      // La función prepara el fondo de color de la etiqueta.
      g.font = "bold 14px system-ui"; g.fillStyle = color(o.id);
      // La función dibuja el fondo de la etiqueta.
      g.fillRect(o.x, o.y - 22, g.measureText(t).width + 12, 22);
      // La función escribe el texto de la etiqueta.
      g.fillStyle = "#fff"; g.fillText(t, o.x + 6, o.y - 6);
      // La función dibuja el punto del centro del objeto.
      g.beginPath(); g.arc(o.x + o.w / 2, o.y + o.h / 2, 4, 0, 7); g.fillStyle = color(o.id); g.fill();
    }
    // La función muestra los datos simulados en la página.
    pintar({ fps: demo.fps, visibles: demo.objs.length, total: sig - 1, conteo: demo.conteo,
      objetos: demo.objs.map((o) => ({ id: o.id, clase: o.clase, confianza: o.conf })),
      historial: demo.hist, config: { resolucion: "640x480", umbral: .5, distancia: 80, margen: 30 } });
  }, 40);
  // La función muestra el lienzo, actualiza los botones y la etiqueta de estado.
  cv.hidden = false; ui(true); estado("Modo demostración", "demo");
  // La función avisa al usuario que los datos son simulados.
  $("msg").textContent = "No se encontró el servidor Flask; se muestran datos simulados.";
}

// Estas líneas conectan los botones con sus funciones.
$("btnIniciar").onclick = iniciar;
$("btnDetener").onclick = () => detener();
// La página consulta el estado del servidor al cargar.
consultar();
