const $ = (id) => document.getElementById(id);
let timer = null;

async function post(url) {
  const r = await fetch(url, { method: "POST" });
  return r.json();
}

async function actualizar() {
  try {
    const e = await (await fetch("/api/estado")).json();
    $("fps").textContent = e.fps;
    $("visibles").textContent = e.visibles;
    $("total").textContent = e.total;
    $("conteo").innerHTML = Object.entries(e.conteo)
      .map(([c, n]) => `<li><span>${c}</span><strong>${n}</strong></li>`).join("") ||
      "<li><span>Sin datos</span></li>";
    $("historial").innerHTML = e.historial
      .map((h) => `<tr><td>${h.hora}</td><td>${h.id}</td><td>${h.clase}</td><td>${h.confianza}%</td></tr>`)
      .join("");
    if (!e.activo && timer) detenerUI();
  } catch (_) {}
}

function detenerUI() {
  clearInterval(timer); timer = null;
  $("video").removeAttribute("src");
}

$("btnIniciar").onclick = async () => {
  $("mensaje").textContent = "Iniciando...";
  const r = await post("/api/iniciar");
  if (!r.ok) { $("mensaje").textContent = "Error: " + r.error; return; }
  $("mensaje").textContent = "En ejecución";
  $("video").src = "/video?" + Date.now();
  if (!timer) timer = setInterval(actualizar, 700);
};

$("btnDetener").onclick = async () => {
  await post("/api/detener");
  detenerUI();
  $("mensaje").textContent = "Detenido";
  actualizar();
};

actualizar();
