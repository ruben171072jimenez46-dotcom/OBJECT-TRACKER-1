"""Módulo de seguimiento por centroides con distancia euclidiana."""
import math

import configuracion as cfg


class Tracker:
    def __init__(self, distancia_maxima=cfg.DISTANCIA_MAXIMA,
                 max_desaparecido=cfg.MAX_FPS_DESAPARECIDO):
        self.distancia_maxima = distancia_maxima
        self.max_desaparecido = max_desaparecido
        self.siguiente_id = 1
        self.objetos = {}      # id -> {clase, centroide, caja, confianza, desaparecido}
        self.conteo = {}       # clase -> total de objetos distintos vistos
        self.nuevos = []       # IDs registrados en la última actualización

    @staticmethod
    def centroide(caja):
        x1, y1, x2, y2 = caja
        return ((x1 + x2) / 2, (y1 + y2) / 2)          # Cx, Cy

    @staticmethod
    def distancia(a, b):
        return math.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)

    def _registrar(self, det, centro):
        id_ = self.siguiente_id
        self.siguiente_id += 1
        self.objetos[id_] = {"clase": det["clase"], "centroide": centro,
                             "caja": det["caja"], "confianza": det["confianza"],
                             "desaparecido": 0}
        self.conteo[det["clase"]] = self.conteo.get(det["clase"], 0) + 1
        self.nuevos.append(id_)
        return id_

    def actualizar(self, detecciones):
        """Asocia las detecciones con los objetos conocidos.
        Devuelve la lista de objetos visibles en este cuadro."""
        self.nuevos = []
        centros = [self.centroide(d["caja"]) for d in detecciones]

        # Pares (distancia, id, índice) compatibles: misma clase y cercanos
        pares = []
        for id_, obj in self.objetos.items():
            for i, det in enumerate(detecciones):
                if obj["clase"] != det["clase"]:
                    continue
                d = self.distancia(obj["centroide"], centros[i])
                if d <= self.distancia_maxima:
                    pares.append((d, id_, i))
        pares.sort()

        ids_usados, dets_usadas, asignacion = set(), set(), {}
        for _, id_, i in pares:                         # emparejamiento voraz
            if id_ in ids_usados or i in dets_usadas:
                continue
            ids_usados.add(id_)
            dets_usadas.add(i)
            asignacion[i] = id_

        # Objetos sin pareja: contar cuadros ausentes y eliminar si se excede el margen
        for id_ in list(self.objetos):
            if id_ not in ids_usados:
                self.objetos[id_]["desaparecido"] += 1
                if self.objetos[id_]["desaparecido"] > self.max_desaparecido:
                    del self.objetos[id_]

        # Detecciones sin pareja: objetos nuevos con identificador nuevo
        for i, det in enumerate(detecciones):
            if i not in dets_usadas:
                asignacion[i] = self._registrar(det, centros[i])

        visibles = []
        for i, det in enumerate(detecciones):
            id_ = asignacion[i]
            obj = self.objetos[id_]
            obj.update(centroide=centros[i], caja=det["caja"],
                       confianza=det["confianza"], desaparecido=0)
            visibles.append({"id": id_, "clase": obj["clase"], "caja": det["caja"],
                             "confianza": det["confianza"], "centroide": centros[i]})
        return visibles
