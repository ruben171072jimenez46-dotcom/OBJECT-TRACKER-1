"""Este módulo da seguimiento a los objetos por centroides y distancia euclidiana."""
# El módulo importa math para calcular la raíz cuadrada.
import math

# El módulo importa la configuración con los límites de seguimiento.
import configuracion as cfg


# La clase Tracker mantiene la identidad de cada objeto entre cuadros consecutivos.
class Tracker:
    # El constructor recibe la distancia máxima y el margen de cuadros sin ver un objeto.
    def __init__(self, distancia_maxima=cfg.DISTANCIA_MAXIMA,
                 max_desaparecido=cfg.MAX_FPS_DESAPARECIDO):
        # El tracker guarda la distancia máxima permitida.
        self.distancia_maxima = distancia_maxima
        # El tracker guarda el margen de cuadros permitido sin ver un objeto.
        self.max_desaparecido = max_desaparecido
        # El tracker inicia el contador de identificadores en 1.
        self.siguiente_id = 1
        # Este diccionario guarda, por cada id, su clase, centroide, caja, confianza y cuadros ausente.
        self.objetos = {}
        # Este diccionario cuenta el total de objetos distintos vistos por clase.
        self.conteo = {}
        # Esta lista contiene los IDs que el tracker registró en la última actualización.
        self.nuevos = []

    # Este método no necesita datos del objeto, por eso es estático.
    @staticmethod
    def centroide(caja):
        # El método separa las cuatro coordenadas de la caja.
        x1, y1, x2, y2 = caja
        # El método calcula el centro del rectángulo (Cx, Cy).
        return ((x1 + x2) / 2, (y1 + y2) / 2)

    # Este método tampoco necesita datos del objeto, por eso es estático.
    @staticmethod
    def distancia(a, b):
        # El método aplica la fórmula de la distancia euclidiana entre los puntos a y b.
        return math.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)

    # Este método registra un objeto nuevo con un identificador nuevo.
    def _registrar(self, det, centro):
        # El método toma el siguiente identificador disponible.
        id_ = self.siguiente_id
        # El método avanza el contador para el próximo objeto.
        self.siguiente_id += 1
        # El método guarda los datos del objeto nuevo.
        self.objetos[id_] = {"clase": det["clase"], "centroide": centro,
                             "caja": det["caja"], "confianza": det["confianza"],
                             "desaparecido": 0}
        # El método suma uno al conteo de la clase del objeto.
        self.conteo[det["clase"]] = self.conteo.get(det["clase"], 0) + 1
        # El método anota que este identificador es nuevo en esta actualización.
        self.nuevos.append(id_)
        # El método devuelve el identificador asignado.
        return id_

    def actualizar(self, detecciones):
        """El método asocia las detecciones con los objetos conocidos y
        devuelve la lista de objetos visibles en el cuadro actual."""
        # El método vacía la lista de identificadores nuevos del cuadro anterior.
        self.nuevos = []
        # El método calcula el centroide de cada detección recibida.
        centros = [self.centroide(d["caja"]) for d in detecciones]

        # El tracker arma los pares (distancia, id, índice) cuya clase coincide y cuya distancia es menor al límite.
        pares = []
        # El método recorre cada objeto ya registrado.
        for id_, obj in self.objetos.items():
            # El método compara ese objeto con cada detección nueva.
            for i, det in enumerate(detecciones):
                # El método ignora las detecciones de otra clase.
                if obj["clase"] != det["clase"]:
                    continue
                # El método mide la distancia entre el centroide anterior y el actual.
                d = self.distancia(obj["centroide"], centros[i])
                # El método conserva el par solo si la distancia no supera el máximo.
                if d <= self.distancia_maxima:
                    pares.append((d, id_, i))
        # El método ordena los pares de menor a mayor distancia.
        pares.sort()

        # El método prepara los conjuntos que registran qué objetos y detecciones ya tienen pareja.
        ids_usados, dets_usadas, asignacion = set(), set(), {}
        # El tracker empareja primero los pares más cercanos (algoritmo voraz).
        for _, id_, i in pares:
            # El método salta el par si el objeto o la detección ya tienen pareja.
            if id_ in ids_usados or i in dets_usadas:
                continue
            # El método marca el objeto como emparejado.
            ids_usados.add(id_)
            # El método marca la detección como emparejada.
            dets_usadas.add(i)
            # El método anota qué identificador corresponde a la detección.
            asignacion[i] = id_

        # El tracker cuenta los cuadros ausentes de cada objeto sin pareja y lo elimina si excede el margen.
        for id_ in list(self.objetos):
            # El método revisa los objetos que no recibieron pareja.
            if id_ not in ids_usados:
                # El método suma un cuadro de ausencia.
                self.objetos[id_]["desaparecido"] += 1
                # El método elimina el objeto si superó el margen permitido.
                if self.objetos[id_]["desaparecido"] > self.max_desaparecido:
                    del self.objetos[id_]

        # El tracker registra cada detección sin pareja como un objeto nuevo con identificador nuevo.
        for i, det in enumerate(detecciones):
            if i not in dets_usadas:
                asignacion[i] = self._registrar(det, centros[i])

        # El método prepara la lista de objetos visibles en este cuadro.
        visibles = []
        # El método recorre cada detección con su identificador asignado.
        for i, det in enumerate(detecciones):
            # El método obtiene el identificador de la detección.
            id_ = asignacion[i]
            # El método obtiene el registro del objeto.
            obj = self.objetos[id_]
            # El método actualiza la posición, la confianza y reinicia el contador de ausencia.
            obj.update(centroide=centros[i], caja=det["caja"],
                       confianza=det["confianza"], desaparecido=0)
            # El método agrega el objeto a la lista de visibles.
            visibles.append({"id": id_, "clase": obj["clase"], "caja": det["caja"],
                             "confianza": det["confianza"], "centroide": centros[i]})
        # El método devuelve los objetos visibles.
        return visibles
